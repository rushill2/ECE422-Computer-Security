from hashlib import md5


flag = 1
i = 1781648353 # Started at 1 originally, but the program would stop at encryptions where the value was offset by 1 and would require a bitshift left or right to be accurate which can't be done with the output value, so I would run it again at the value left off. 1781648352 was the last "hit" value.
while (flag):
	str2hash = str(i)
	result = md5(str2hash.encode())
	output = str(result.hexdigest()) # MD5 hashed output
	if ("274f522731" in output) or ("277c7c2731" in output) or ("277c7c2732" in output) or ("277c7c2733" in output) or ("277c7c2734" in output) or ("277c7c2735" in output) or ("277c7c2736" in output) or ("277c7c2737" in output) or ("277c7c2738" in output) or ("277c7c2739" in output) or ("274f522732" in output) or ("274f522733" in output) or ("274f522734" in output) or ("274f522735" in output) or ("274f522736" in output) or ("274f522737" in output) or ("274f522738" in output) or ("274f522739" in output) or ("276f522731" in output) or ("276f522732" in output) or ("276f522733" in output) or ("276f522734" in output) or ("276f522735" in output) or ("276f522736" in output) or ("276f522737" in output) or ("276f522738" in output) or ("276f522739" in output) or ("276f722731" in output) or ("276f722732" in output) or ("276f722733" in output) or ("276f722734" in output) or ("276f722735" in output) or ("276f722736" in output) or ("276f722737" in output) or ("276f722738" in output) or ("276f722739" in output): # Checks for 'OR' 1-9, 'oR' 1-9, 'or'1-9, '||'1-9. Could have added 'Or' 1-9 to be faster, but I got lazy.
		print(output)
		print(str2hash)
		flag = 0 # This script took awhile to run I ended with i = 2413633098.
	i += 1
	print(i)
